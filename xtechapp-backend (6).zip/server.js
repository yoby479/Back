require('dotenv').config();
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const admin = require('firebase-admin');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const { v4: uuidv4 } = require('uuid');

// Initialize Firebase Admin
let serviceAccount;
let firebaseAdminReady = false;
try {
  serviceAccount = require('./firebase-service-account.json');
  if (serviceAccount.private_key === 'REPLACE_WITH_YOUR_PRIVATE_KEY' || !serviceAccount.private_key) {
    console.log('[FIREBASE] Service account not configured properly, using project ID only');
    admin.initializeApp({ projectId: process.env.FIREBASE_PROJECT_ID || 'trade-ff4a4' });
  } else {
    console.log('[FIREBASE] Initializing with service account:', serviceAccount.client_email);
    admin.initializeApp({ credential: admin.credential.cert(serviceAccount) });
    firebaseAdminReady = true;
  }
} catch (e) {
  console.log('[FIREBASE] No service account found, initializing with project ID:', e.message);
  admin.initializeApp({ projectId: process.env.FIREBASE_PROJECT_ID || 'trade-ff4a4' });
}

const db = admin.firestore();
const auth = admin.auth();

console.log('[FIREBASE] Admin SDK ready:', firebaseAdminReady);
console.log('[FIREBASE] Project ID:', process.env.FIREBASE_PROJECT_ID || 'trade-ff4a4');

const app = express();
const server = http.createServer(app);

const io = new Server(server, {
  cors: { origin: '*', methods: ['GET', 'POST'] },
  pingTimeout: 60000,
  pingInterval: 25000
});

// Middleware
app.use(cors());
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// Rate limiting
const limiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 1000 });
app.use('/api/', limiter);

// Upload config
const uploadDir = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true });

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadDir),
  filename: (req, file, cb) => cb(null, uuidv4() + path.extname(file.originalname))
});
const upload = multer({ storage, limits: { fileSize: 50 * 1024 * 1024 } });

app.use('/uploads', express.static(uploadDir));

// ============ AUTH MIDDLEWARE ============
async function verifyToken(req, res, next) {
  const token = req.headers.authorization?.split('Bearer ')[1];
  if (!token) return res.status(401).json({ error: 'No token provided' });
  try {
    const decoded = await auth.verifyIdToken(token);
    req.user = decoded;
    next();
  } catch (err) {
    return res.status(401).json({ error: 'Invalid token' });
  }
}

function getClientIP(req) {
  return req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.socket?.remoteAddress || 'unknown';
}

// ============ AUTH ROUTES ============

// Register with existing Firebase Auth UID (client-side registration sync)
app.post('/api/auth/register', async (req, res) => {
  try {
    const { email, password, name, phone, uid } = req.body;
    if (!email || !name) {
      return res.status(400).json({ error: 'Email and name are required' });
    }

    const clientIP = getClientIP(req);
    let userUid = uid;
    
    // If uid provided (client-side Firebase Auth registration), use it
    if (!userUid) {
      if (!password || password.length < 6) {
        return res.status(400).json({ error: 'Password must be at least 6 characters' });
      }
      try {
        const userRecord = await auth.createUser({ email, password, displayName: name });
        userUid = userRecord.uid;
        console.log('[AUTH] Created Firebase Auth user via Admin SDK:', userUid);
      } catch (authErr) {
        if (authErr.code === 'auth/email-already-exists') {
          return res.status(400).json({ error: 'Email already registered' });
        }
        throw authErr;
      }
    }

    // Check if profile already exists
    const existingDoc = await db.collection('users').doc(userUid).get();
    if (existingDoc.exists) {
      return res.json({ message: 'User profile already exists', uid: userUid });
    }

    // Store user profile in Firestore
    await db.collection('users').doc(userUid).set({
      uid: userUid,
      email,
      name,
      about: 'Hey there! I am using X_TECH',
      profilePic: '',
      phone: phone || '',
      lastSeen: admin.firestore.FieldValue.serverTimestamp(),
      online: true,
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
      ip: clientIP
    });

    // Register IP
    try {
      await db.collection('ip_registry').add({
        ip: clientIP,
        uid: userUid,
        createdAt: admin.firestore.FieldValue.serverTimestamp()
      });
    } catch(ipErr) {
      console.warn('IP registry failed:', ipErr.message);
    }

    console.log('[AUTH] User profile created:', userUid, email);
    res.status(201).json({ message: 'User created successfully', uid: userUid });
  } catch (err) {
    console.error('[AUTH] Register error:', err);
    res.status(500).json({ error: 'Registration failed: ' + err.message });
  }
});

// DIRECT registration - backend creates Firebase Auth user + Firestore profile + returns custom token
// This is the FALLBACK path when client-side Firebase Auth doesn't work
app.post('/api/auth/register-direct', async (req, res) => {
  try {
    const { email, password, name, phone } = req.body;
    
    console.log('[AUTH] Direct registration request:', email, name);
    
    if (!email || !name) {
      return res.status(400).json({ error: 'Email and name are required' });
    }
    if (!password || password.length < 6) {
      return res.status(400).json({ error: 'Password must be at least 6 characters' });
    }

    const clientIP = getClientIP(req);
    let userUid;

    // Validate phone number format for Firebase (must be E.164 like +254712345678)
    let validPhone = phone || '';
    if (validPhone && !/^\+\d{7,15}$/.test(validPhone.replace(/[\s\-\(\)]/g, ''))) {
      console.log('[AUTH] Phone number format not E.164, storing but not setting in Auth:', validPhone);
      validPhone = ''; // Don't pass invalid phone to Firebase Auth
    }
    const phoneForAuth = validPhone || undefined;

    // Create Firebase Auth user via Admin SDK
    try {
      const createParams = { email, password, displayName: name };
      if (phoneForAuth) createParams.phoneNumber = phoneForAuth;
      const userRecord = await auth.createUser(createParams);
      userUid = userRecord.uid;
      console.log('[AUTH] Created Firebase Auth user:', userUid);
    } catch (authErr) {
      console.error('[AUTH] Firebase Auth create error:', authErr.code, authErr.message);
      if (authErr.code === 'auth/email-already-exists') {
        return res.status(400).json({ error: 'This email is already registered. Try signing in instead.' });
      }
      if (authErr.code === 'auth/invalid-email') {
        return res.status(400).json({ error: 'Invalid email address.' });
      }
      if (authErr.code === 'auth/weak-password') {
        return res.status(400).json({ error: 'Password is too weak. Use 6+ characters.' });
      }
      if (authErr.code === 'auth/invalid-phone-number') {
        // Retry without phone number
        try {
          const userRecord = await auth.createUser({ email, password, displayName: name });
          userUid = userRecord.uid;
          console.log('[AUTH] Created Firebase Auth user (without phone):', userUid);
        } catch(retryErr) {
          if (retryErr.code === 'auth/email-already-exists') {
            return res.status(400).json({ error: 'This email is already registered. Try signing in instead.' });
          }
          return res.status(500).json({ error: 'Could not create account: ' + retryErr.message });
        }
      } else {
        return res.status(500).json({ error: 'Could not create account: ' + authErr.message });
      }
    }

    // Create custom token for client sign-in
    let customToken = '';
    try {
      customToken = await auth.createCustomToken(userUid);
    } catch(tokenErr) {
      console.warn('[AUTH] Custom token creation failed:', tokenErr.message);
    }

    // Store user profile in Firestore
    try {
      const existingDoc = await db.collection('users').doc(userUid).get();
      if (!existingDoc.exists) {
        await db.collection('users').doc(userUid).set({
          uid: userUid,
          email,
          name,
          about: 'Hey there! I am using X_TECH',
          profilePic: '',
          phone: phone || validPhone || '',
          lastSeen: admin.firestore.FieldValue.serverTimestamp(),
          online: true,
          createdAt: admin.firestore.FieldValue.serverTimestamp(),
          ip: clientIP
        });
      }
    } catch(firestoreErr) {
      console.warn('[AUTH] Firestore profile creation failed:', firestoreErr.message);
      // Don't fail the whole registration - the user exists in Firebase Auth
    }

    // Register IP
    try {
      await db.collection('ip_registry').add({
        ip: clientIP,
        uid: userUid,
        createdAt: admin.firestore.FieldValue.serverTimestamp()
      });
    } catch(ipErr) {
      console.warn('IP registry failed:', ipErr.message);
    }

    console.log('[AUTH] Direct registration SUCCESS:', userUid, email);
    res.status(201).json({
      message: 'User created successfully',
      uid: userUid,
      customToken
    });
  } catch (err) {
    console.error('[AUTH] Direct register error:', err);
    res.status(500).json({ error: 'Registration failed: ' + err.message });
  }
});

// Login with ID token (client-side Firebase Auth login sync)
app.post('/api/auth/login', async (req, res) => {
  try {
    const { idToken } = req.body;
    if (!idToken) return res.status(400).json({ error: 'ID token required' });

    const decoded = await auth.verifyIdToken(idToken);
    const userDoc = await db.collection('users').doc(decoded.uid).get();

    if (!userDoc.exists) {
      // Auto-create profile if missing
      const clientIP = getClientIP(req);
      await db.collection('users').doc(decoded.uid).set({
        uid: decoded.uid,
        email: decoded.email || '',
        name: decoded.name || decoded.email?.split('@')[0] || 'User',
        about: 'Hey there! I am using X_TECH',
        profilePic: decoded.picture || '',
        phone: decoded.phone_number || '',
        lastSeen: admin.firestore.FieldValue.serverTimestamp(),
        online: true,
        createdAt: admin.firestore.FieldValue.serverTimestamp(),
        ip: clientIP
      });
      const newDoc = await db.collection('users').doc(decoded.uid).get();
      return res.json({ user: { uid: decoded.uid, ...newDoc.data() } });
    }

    await db.collection('users').doc(decoded.uid).update({
      online: true,
      lastSeen: admin.firestore.FieldValue.serverTimestamp()
    });

    res.json({ user: { uid: decoded.uid, ...userDoc.data() } });
  } catch (err) {
    console.error('[AUTH] Login error:', err.message);
    res.status(401).json({ error: 'Login failed: ' + err.message });
  }
});

// DIRECT login - backend verifies email/password and returns custom token
// This is the FALLBACK path when client-side Firebase Auth doesn't work
app.post('/api/auth/login-direct', async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) return res.status(400).json({ error: 'Email and password required' });

    console.log('[AUTH] Direct login request:', email);

    // We can't verify password directly with Firebase Admin SDK
    // Instead, we try to look up the user and create a custom token
    try {
      const userRecord = await auth.getUserByEmail(email);
      
      // User exists - create custom token
      const customToken = await auth.createCustomToken(userRecord.uid);
      
      // Update online status
      try {
        await db.collection('users').doc(userRecord.uid).update({
          online: true,
          lastSeen: admin.firestore.FieldValue.serverTimestamp()
        });
      } catch(e) {}

      const userDoc = await db.collection('users').doc(userRecord.uid).get();
      const userData = userDoc.exists ? userDoc.data() : { name: userRecord.displayName || email };

      console.log('[AUTH] Direct login SUCCESS:', userRecord.uid);
      res.json({
        uid: userRecord.uid,
        customToken,
        name: userData.name,
        email: userRecord.email
      });
    } catch(userErr) {
      if (userErr.code === 'auth/user-not-found') {
        return res.status(404).json({ error: 'No account found with this email.' });
      }
      throw userErr;
    }
  } catch (err) {
    console.error('[AUTH] Direct login error:', err);
    res.status(401).json({ error: 'Login failed' });
  }
});

app.post('/api/auth/check-ip', async (req, res) => {
  try {
    const clientIP = getClientIP(req);
    const maxAccounts = parseInt(process.env.MAX_ACCOUNTS_PER_IP) || 1;
    const ipSnapshot = await db.collection('ip_registry').where('ip', '==', clientIP).get();
    res.json({ allowed: ipSnapshot.size < maxAccounts, current: ipSnapshot.size, max: maxAccounts });
  } catch (err) {
    res.json({ allowed: true, current: 0, max: 1 });
  }
});

// ============ USER ROUTES ============
app.get('/api/users/profile/:uid', verifyToken, async (req, res) => {
  try {
    const userDoc = await db.collection('users').doc(req.params.uid).get();
    if (!userDoc.exists) return res.status(404).json({ error: 'User not found' });
    res.json({ user: userDoc.data() });
  } catch (err) {
    res.status(500).json({ error: 'Failed to get profile' });
  }
});

app.put('/api/users/profile', verifyToken, async (req, res) => {
  try {
    const { name, about, phone } = req.body;
    const updates = {};
    if (name) updates.name = name;
    if (about !== undefined) updates.about = about;
    if (phone !== undefined) updates.phone = phone;

    await db.collection('users').doc(req.user.uid).update(updates);
    res.json({ message: 'Profile updated' });
  } catch (err) {
    res.status(500).json({ error: 'Failed to update profile' });
  }
});

app.post('/api/users/profile-pic', verifyToken, upload.single('profilePic'), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ error: 'No file uploaded' });
    const profilePicUrl = `${req.protocol}://${req.get('host')}/uploads/${req.file.filename}`;
    await db.collection('users').doc(req.user.uid).update({ profilePic: profilePicUrl });
    res.json({ profilePic: profilePicUrl });
  } catch (err) {
    res.status(500).json({ error: 'Failed to upload profile picture' });
  }
});

app.post('/api/users/bg-photo', verifyToken, upload.single('bgPhoto'), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ error: 'No file uploaded' });
    const bgPhotoUrl = `${req.protocol}://${req.get('host')}/uploads/${req.file.filename}`;
    await db.collection('users').doc(req.user.uid).update({ bgPhoto: bgPhotoUrl });
    res.json({ bgPhotoUrl });
  } catch (err) {
    res.status(500).json({ error: 'Failed to upload background photo' });
  }
});

app.post('/api/users/fcm-token', verifyToken, async (req, res) => {
  try {
    const { fcmToken } = req.body;
    if (!fcmToken) return res.status(400).json({ error: 'FCM token required' });
    await db.collection('users').doc(req.user.uid).update({ fcmToken });
    res.json({ message: 'FCM token updated' });
  } catch (err) {
    res.status(500).json({ error: 'Failed to update FCM token' });
  }
});

app.get('/api/users/search', verifyToken, async (req, res) => {
  try {
    const { q } = req.query;
    if (!q) return res.json({ users: [] });
    const snapshot = await db.collection('users').limit(20).get();
    const users = [];
    snapshot.forEach(doc => {
      const data = doc.data();
      if (data.uid !== req.user.uid && (data.name?.toLowerCase().includes(q.toLowerCase()) || data.email?.toLowerCase().includes(q.toLowerCase()) || data.phone?.includes(q))) {
        users.push(data);
      }
    });
    res.json({ users });
  } catch (err) {
    res.status(500).json({ error: 'Search failed' });
  }
});

// ============ CONTACTS SYNC ============
app.post('/api/contacts/sync', verifyToken, async (req, res) => {
  try {
    const { phoneNumbers } = req.body;
    if (!phoneNumbers || !Array.isArray(phoneNumbers)) {
      return res.status(400).json({ error: 'Phone numbers array required' });
    }

    const snapshot = await db.collection('users').get();
    const registeredUsers = {};
    snapshot.forEach(doc => {
      const data = doc.data();
      if (data.phone && data.uid !== req.user.uid) {
        let normalizedPhone = data.phone.replace(/[\s\-\(\)]/g, '');
        registeredUsers[normalizedPhone] = data;
      }
    });

    const matchedContacts = [];
    const matchedUids = new Set();
    phoneNumbers.forEach(pn => {
      let num = pn.number.replace(/[\s\-\(\)]/g, '');
      if (registeredUsers[num] && !matchedUids.has(registeredUsers[num].uid)) {
        matchedContacts.push(registeredUsers[num]);
        matchedUids.add(registeredUsers[num].uid);
      }
      const numNoPlus = num.replace(/^\+/, '');
      if (registeredUsers[numNoPlus] && !matchedUids.has(registeredUsers[numNoPlus].uid)) {
        matchedContacts.push(registeredUsers[numNoPlus]);
        matchedUids.add(registeredUsers[numNoPlus].uid);
      }
      const numWithPlus = num.startsWith('+') ? num : '+' + num;
      if (registeredUsers[numWithPlus] && !matchedUids.has(registeredUsers[numWithPlus].uid)) {
        matchedContacts.push(registeredUsers[numWithPlus]);
        matchedUids.add(registeredUsers[numWithPlus].uid);
      }
    });

    res.json({ contacts: matchedContacts, totalMatched: matchedContacts.length });
  } catch (err) {
    console.error('Contacts sync error:', err);
    res.status(500).json({ error: 'Failed to sync contacts' });
  }
});

// ============ CHAT ROUTES ============
app.post('/api/chats', verifyToken, async (req, res) => {
  try {
    const { recipientId } = req.body;
    if (!recipientId) return res.status(400).json({ error: 'Recipient required' });

    const existingChat = await db.collection('chats')
      .where('participants', 'array-contains', req.user.uid)
      .get();

    let chat = null;
    existingChat.forEach(doc => {
      const data = doc.data();
      if (data.participants.includes(recipientId) && data.type === 'individual') {
        chat = { id: doc.id, ...data };
      }
    });

    if (chat) return res.json({ chat });

    const chatRef = db.collection('chats').doc();
    const recipientDoc = await db.collection('users').doc(recipientId).get();
    const recipientData = recipientDoc.exists ? recipientDoc.data() : {};

    await chatRef.set({
      id: chatRef.id,
      participants: [req.user.uid, recipientId],
      participantDetails: {
        [req.user.uid]: { name: req.user.name || req.user.email },
        [recipientId]: { name: recipientData.name || 'User' }
      },
      type: 'individual',
      lastMessage: '',
      lastMessageTime: admin.firestore.FieldValue.serverTimestamp(),
      lastMessageSender: '',
      unreadCount: 0,
      createdAt: admin.firestore.FieldValue.serverTimestamp()
    });

    res.status(201).json({ chat: { id: chatRef.id, participants: [req.user.uid, recipientId], type: 'individual' } });
  } catch (err) {
    console.error('Create chat error:', err);
    res.status(500).json({ error: 'Failed to create chat' });
  }
});

app.get('/api/chats', verifyToken, async (req, res) => {
  try {
    const snapshot = await db.collection('chats')
      .where('participants', 'array-contains', req.user.uid)
      .orderBy('lastMessageTime', 'desc')
      .get();

    const chats = [];
    for (const doc of snapshot.docs) {
      const chatData = doc.data();
      const otherUid = chatData.participants.find(p => p !== req.user.uid);
      let otherUser = { name: 'User', profilePic: '' };
      if (otherUid) {
        const userDoc = await db.collection('users').doc(otherUid).get();
        if (userDoc.exists) otherUser = userDoc.data();
      }
      chats.push({ ...chatData, otherUser });
    }
    res.json({ chats });
  } catch (err) {
    console.error('Get chats error:', err);
    res.status(500).json({ error: 'Failed to get chats' });
  }
});

// ============ MESSAGE ROUTES ============
app.get('/api/chats/:chatId/messages', verifyToken, async (req, res) => {
  try {
    const { chatId } = req.params;
    const limit = parseInt(req.query.limit) || 50;
    const offset = req.query.offset || null;

    let query = db.collection('messages')
      .where('chatId', '==', chatId)
      .orderBy('timestamp', 'desc')
      .limit(limit);

    if (offset) {
      const offsetDoc = await db.collection('messages').doc(offset).get();
      if (offsetDoc.exists) query = query.startAfter(offsetDoc);
    }

    const snapshot = await query.get();
    const messages = [];
    snapshot.forEach(doc => messages.push({ id: doc.id, ...doc.data() }));
    res.json({ messages: messages.reverse() });
  } catch (err) {
    console.error('Get messages error:', err);
    res.status(500).json({ error: 'Failed to get messages' });
  }
});

app.post('/api/messages', verifyToken, async (req, res) => {
  try {
    const { chatId, text, mediaUrl, mediaType } = req.body;
    if (!chatId || (!text && !mediaUrl)) {
      return res.status(400).json({ error: 'Chat ID and message content required' });
    }

    const msgRef = db.collection('messages').doc();
    const message = {
      id: msgRef.id,
      chatId,
      senderId: req.user.uid,
      text: text || '',
      mediaUrl: mediaUrl || '',
      mediaType: mediaType || 'text',
      timestamp: admin.firestore.FieldValue.serverTimestamp(),
      read: false,
      readBy: []
    };

    await msgRef.set(message);

    await db.collection('chats').doc(chatId).update({
      lastMessage: text || (mediaType === 'image' ? '📷 Photo' : mediaType === 'voice' ? '🎤 Voice' : '📎 File'),
      lastMessageTime: admin.firestore.FieldValue.serverTimestamp(),
      lastMessageSender: req.user.uid
    });

    const chatDoc = await db.collection('chats').doc(chatId).get();
    if (chatDoc.exists) {
      const chatData = chatDoc.data();
      for (const pid of chatData.participants) {
        if (pid !== req.user.uid) {
          io.to(pid).emit('new-message', { ...message, senderName: req.user.name || '' });
          const onlineSocketId = onlineUsers.get(pid);
          if (!onlineSocketId) {
            try {
              const recipientDoc = await db.collection('users').doc(pid).get();
              const recipientData = recipientDoc.data();
              if (recipientData?.fcmToken) {
                await admin.messaging().send({
                  token: recipientData.fcmToken,
                  notification: {
                    title: req.user.name || 'xtechapp',
                    body: text || (mediaType === 'image' ? '📷 Photo' : 'New message')
                  },
                  data: { type: 'message', chatId, fromUid: req.user.uid },
                  android: { priority: 'high' }
                });
              }
            } catch (pushErr) {
              console.error('Push notification failed:', pushErr.message);
            }
          }
        }
      }
    }

    res.status(201).json({ message });
  } catch (err) {
    console.error('Send message error:', err);
    res.status(500).json({ error: 'Failed to send message' });
  }
});

app.post('/api/messages/media', verifyToken, upload.single('media'), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ error: 'No file uploaded' });
    const mediaUrl = `${req.protocol}://${req.get('host')}/uploads/${req.file.filename}`;
    const mimeType = req.file.mimetype;
    let mediaType = 'file';
    if (mimeType.startsWith('image')) mediaType = 'image';
    else if (mimeType.startsWith('video')) mediaType = 'video';
    else if (mimeType.startsWith('audio')) mediaType = 'voice';
    else if (mimeType.includes('pdf') || mimeType.includes('document') || mimeType.includes('sheet') || mimeType.includes('presentation') || mimeType.includes('zip') || mimeType.includes('text')) mediaType = 'file';
    res.json({ mediaUrl, mediaType });
  } catch (err) {
    res.status(500).json({ error: 'Failed to upload media' });
  }
});

// ============ CONTACTS ROUTE ============
app.get('/api/contacts', verifyToken, async (req, res) => {
  try {
    const snapshot = await db.collection('users').limit(100).get();
    const contacts = [];
    snapshot.forEach(doc => {
      const data = doc.data();
      if (data.uid !== req.user.uid) contacts.push(data);
    });
    res.json({ contacts });
  } catch (err) {
    res.status(500).json({ error: 'Failed to get contacts' });
  }
});

// ============ GROUP ROUTES ============
app.post('/api/groups', verifyToken, async (req, res) => {
  try {
    const { name, members } = req.body;
    if (!name) return res.status(400).json({ error: 'Group name required' });
    if (!members || members.length < 1) return res.status(400).json({ error: 'At least 1 member required' });

    const allMembers = [req.user.uid, ...members];
    const groupRef = db.collection('chats').doc();
    await groupRef.set({
      id: groupRef.id,
      participants: allMembers,
      name,
      type: 'group',
      createdBy: req.user.uid,
      inviteLink: `https://xtechapp.guru.qzz.io/invite/${groupRef.id}`,
      lastMessage: '',
      lastMessageTime: admin.firestore.FieldValue.serverTimestamp(),
      lastMessageSender: '',
      unreadCount: 0,
      createdAt: admin.firestore.FieldValue.serverTimestamp()
    });

    res.status(201).json({ chat: { id: groupRef.id, name, type: 'group', participants: allMembers, inviteLink: `https://xtechapp.guru.qzz.io/invite/${groupRef.id}` } });
  } catch (err) {
    console.error('Create group error:', err);
    res.status(500).json({ error: 'Failed to create group' });
  }
});

app.post('/api/groups/join', verifyToken, async (req, res) => {
  try {
    const { groupId } = req.body;
    if (!groupId) return res.status(400).json({ error: 'Group ID required' });

    const groupDoc = await db.collection('chats').doc(groupId).get();
    if (!groupDoc.exists) return res.status(404).json({ error: 'Group not found' });

    const groupData = groupDoc.data();
    if (groupData.type !== 'group') return res.status(400).json({ error: 'Not a group' });
    if (groupData.participants.includes(req.user.uid)) return res.json({ chat: groupData });

    await db.collection('chats').doc(groupId).update({
      participants: admin.firestore.FieldValue.arrayUnion(req.user.uid)
    });

    const updatedDoc = await db.collection('chats').doc(groupId).get();
    res.json({ chat: updatedDoc.data() });
  } catch (err) {
    console.error('Join group error:', err);
    res.status(500).json({ error: 'Failed to join group' });
  }
});

app.get('/api/groups/:groupId/invite', async (req, res) => {
  try {
    const { groupId } = req.params;
    const groupDoc = await db.collection('chats').doc(groupId).get();
    if (!groupDoc.exists) return res.status(404).json({ error: 'Group not found' });
    const groupData = groupDoc.data();
    if (groupData.type !== 'group') return res.status(400).json({ error: 'Not a group' });
    res.json({ inviteLink: groupData.inviteLink || `https://xtechapp.guru.qzz.io/invite/${groupId}`, name: groupData.name });
  } catch (err) {
    res.status(500).json({ error: 'Failed to get invite link' });
  }
});

// ============ STATUS ROUTES ============
app.post('/api/status', verifyToken, async (req, res) => {
  try {
    const { text, background } = req.body;
    const statusRef = db.collection('status').doc();
    await statusRef.set({
      id: statusRef.id,
      userId: req.user.uid,
      userName: req.user.name || 'User',
      text: text || '',
      background: background || '#25D366',
      timestamp: admin.firestore.FieldValue.serverTimestamp(),
      expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000)
    });
    res.status(201).json({ message: 'Status posted' });
  } catch (err) {
    res.status(500).json({ error: 'Failed to post status' });
  }
});

app.get('/api/status', verifyToken, async (req, res) => {
  try {
    const snapshot = await db.collection('status')
      .where('expiresAt', '>', new Date())
      .orderBy('timestamp', 'desc')
      .get();
    const statuses = [];
    snapshot.forEach(doc => statuses.push(doc.data()));
    res.json({ statuses });
  } catch (err) {
    res.status(500).json({ error: 'Failed to get statuses' });
  }
});

// ============ HEALTH CHECK ============
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', service: 'xtechapp-backend', firebase: firebaseAdminReady, timestamp: new Date().toISOString() });
});

// ============ SOCKET.IO ============
const onlineUsers = new Map();

io.use(async (socket, next) => {
  const token = socket.handshake.auth?.token;
  if (!token) return next(new Error('Authentication required'));
  try {
    const decoded = await auth.verifyIdToken(token);
    socket.user = decoded;
    next();
  } catch (err) {
    next(new Error('Invalid token'));
  }
});

io.on('connection', (socket) => {
  const uid = socket.user?.uid;
  if (!uid) return socket.disconnect();

  console.log(`[SOCKET] User connected: ${uid}`);
  onlineUsers.set(uid, socket.id);
  io.emit('user-online', { uid });
  db.collection('users').doc(uid).update({ online: true, lastSeen: admin.firestore.FieldValue.serverTimestamp() }).catch(()=>{});

  socket.join(uid);

  socket.on('join-chat', (chatId) => {
    socket.join(chatId);
  });

  socket.on('leave-chat', (chatId) => {
    socket.leave(chatId);
  });

  socket.on('send-message', async (data) => {
    try {
      const { chatId, text, mediaUrl, mediaType } = data;
      if (!chatId || (!text && !mediaUrl)) return;

      const msgRef = db.collection('messages').doc();
      const message = {
        id: msgRef.id,
        chatId,
        senderId: uid,
        text: text || '',
        mediaUrl: mediaUrl || '',
        mediaType: mediaType || 'text',
        timestamp: admin.firestore.FieldValue.serverTimestamp(),
        read: false,
        readBy: []
      };

      await msgRef.set(message);
      await db.collection('chats').doc(chatId).update({
        lastMessage: text || (mediaType === 'image' ? '📷 Photo' : '📎 File'),
        lastMessageTime: admin.firestore.FieldValue.serverTimestamp(),
        lastMessageSender: uid
      });

      io.to(chatId).emit('new-message', message);

      const chatDoc = await db.collection('chats').doc(chatId).get();
      if (chatDoc.exists) {
        chatDoc.data().participants.forEach(pid => {
          if (pid !== uid) io.to(pid).emit('new-message', message);
        });
      }
    } catch (err) {
      console.error('Socket message error:', err);
      socket.emit('error-message', { error: 'Failed to send message' });
    }
  });

  socket.on('typing', (data) => {
    socket.to(data.chatId).emit('user-typing', { chatId: data.chatId, userId: uid });
  });

  socket.on('stop-typing', (data) => {
    socket.to(data.chatId).emit('user-stop-typing', { chatId: data.chatId, userId: uid });
  });

  socket.on('message-read', async (data) => {
    try {
      const { messageId, chatId } = data;
      await db.collection('messages').doc(messageId).update({
        read: true,
        readBy: admin.firestore.FieldValue.arrayUnion(uid)
      });
      io.to(chatId).emit('message-read', { messageId, readBy: uid });
    } catch (err) {
      console.error('Mark read error:', err);
    }
  });

  // ============ WEBRTC SIGNALING ============
  socket.on('call-user', async (data) => {
    const { targetUserId, offer, callType } = data;
    const targetSocketId = onlineUsers.get(targetUserId);
    if (targetSocketId) {
      io.to(targetSocketId).emit('incoming-call', {
        from: uid,
        offer,
        callType,
        callerName: socket.user?.name || 'Unknown'
      });
    } else {
      try {
        const recipientDoc = await db.collection('users').doc(targetUserId).get();
        const recipientData = recipientDoc.data();
        if (recipientData?.fcmToken) {
          await admin.messaging().send({
            token: recipientData.fcmToken,
            notification: {
              title: socket.user?.name || 'xtechapp',
              body: callType === 'video' ? 'Video Call' : 'Voice Call'
            },
            data: { type: 'call', callType, fromUid: uid },
            android: { priority: 'high' }
          });
        }
      } catch (pushErr) {
        console.error('Call push notification failed:', pushErr.message);
      }
      socket.emit('call-failed', { reason: 'User is offline' });
    }
  });

  socket.on('answer-call', (data) => {
    const { targetUserId, answer } = data;
    const targetSocketId = onlineUsers.get(targetUserId);
    if (targetSocketId) {
      io.to(targetSocketId).emit('call-answered', { from: uid, answer });
    }
  });

  socket.on('ice-candidate', (data) => {
    const { targetUserId, candidate } = data;
    const targetSocketId = onlineUsers.get(targetUserId);
    if (targetSocketId) {
      io.to(targetSocketId).emit('ice-candidate', { from: uid, candidate });
    }
  });

  socket.on('call-ended', (data) => {
    const { targetUserId } = data;
    const targetSocketId = onlineUsers.get(targetUserId);
    if (targetSocketId) {
      io.to(targetSocketId).emit('call-ended', { from: uid });
    }
  });

  socket.on('screen-share-started', (data) => {
    const { targetUserId, userName } = data;
    const targetSocketId = onlineUsers.get(targetUserId);
    if (targetSocketId) {
      io.to(targetSocketId).emit('screen-share-started', { userName, from: uid });
    }
  });

  socket.on('screen-share-stopped', (data) => {
    const { targetUserId } = data;
    const targetSocketId = onlineUsers.get(targetUserId);
    if (targetSocketId) {
      io.to(targetSocketId).emit('screen-share-stopped', { from: uid });
    }
  });

  // ============ DISCONNECT ============
  socket.on('disconnect', () => {
    console.log(`[SOCKET] User disconnected: ${uid}`);
    onlineUsers.delete(uid);
    io.emit('user-offline', { uid });
    db.collection('users').doc(uid).update({
      online: false,
      lastSeen: admin.firestore.FieldValue.serverTimestamp()
    }).catch(() => {});
  });
});

// Error handling
app.use((err, req, res, next) => {
  console.error('Server error:', err);
  res.status(500).json({ error: 'Internal server error' });
});

const PORT = process.env.PORT || 5000;
server.listen(PORT, '0.0.0.0', () => {
  console.log(`[XTECHAPP] Backend server running on port ${PORT}`);
  console.log(`[XTECHAPP] Firebase Admin SDK ready: ${firebaseAdminReady}`);
  console.log(`[XTECHAPP] Firebase project: ${process.env.FIREBASE_PROJECT_ID || 'trade-ff4a4'}`);
  console.log(`[XTECHAPP] Max accounts per IP: ${process.env.MAX_ACCOUNTS_PER_IP || 1}`);
});
