# xtechapp Backend - Deployment Guide

## Quick Deploy on VPS (213.163.205.104)

### Step 1: Install Node.js on VPS
```bash
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs
```

### Step 2: Upload and Extract
Upload `xtechapp-backend.zip` to your VPS and extract:
```bash
mkdir -p /opt/xtechapp
cd /opt/xtechapp
unzip xtechapp-backend.zip
```

### Step 3: Configure Firebase Service Account
1. Go to Firebase Console > Project Settings > Service Accounts
2. Click "Generate New Private Key"
3. Download the JSON file
4. Replace `firebase-service-account.json` with the downloaded file

### Step 4: Configure Environment
Edit `.env` file:
```
PORT=5000
FIREBASE_PROJECT_ID=trade-ff4a4
FIREBASE_STORAGE_BUCKET=trade-ff4a4.firebasestorage.app
JWT_SECRET=change-this-to-a-random-secret
MAX_ACCOUNTS_PER_IP=1
NODE_ENV=production
```

### Step 5: Install Dependencies and Start
```bash
npm install --production
npm start
```

### Step 6: Run with PM2 (keeps server running)
```bash
npm install -g pm2
pm2 start server.js --name xtechapp
pm2 save
pm2 startup
```

### Step 7: Open Firewall
```bash
sudo ufw allow 5000
```

## API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | /api/auth/register | Register with email/password |
| POST | /api/auth/login | Login with Firebase ID token |
| POST | /api/auth/check-ip | Check IP account limit |
| GET | /api/users/profile/:uid | Get user profile |
| PUT | /api/users/profile | Update profile |
| POST | /api/users/profile-pic | Upload profile picture |
| GET | /api/users/search?q= | Search users |
| POST | /api/chats | Create new chat |
| GET | /api/chats | Get user's chats |
| GET | /api/chats/:chatId/messages | Get chat messages |
| POST | /api/messages | Send message |
| POST | /api/messages/media | Upload media |
| GET | /api/contacts | Get contacts |
| POST | /api/status | Post status |
| GET | /api/status | Get statuses |
| GET | /api/health | Health check |

## Socket.io Events

- `join-chat` / `leave-chat` - Join/leave chat rooms
- `send-message` / `new-message` - Real-time messaging
- `typing` / `stop-typing` - Typing indicators
- `message-read` - Read receipts
- `call-user` / `answer-call` - WebRTC signaling
- `ice-candidate` - ICE candidate exchange
- `call-ended` - End call
- `user-online` / `user-offline` - Presence

## Notes
- The backend uses Firebase Firestore as database
- Make sure your Firebase project has Firestore enabled
- IP-based account limiting is enforced (1 account per IP by default)
- Uploads are stored in the `uploads/` directory
