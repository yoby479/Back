# xtechapp Backend - Deployment Guide

## Your Firebase Project: trade-ff4a4

### Firebase Config (Already Configured)
```
apiKey: AIzaSyC2RduTONmVUWcdLJtYhg-ZkXWEXIhZAvo
authDomain: trade-ff4a4.firebaseapp.com
projectId: trade-ff4a4
storageBucket: trade-ff4a4.firebasestorage.app
messagingSenderId: 1084019484887
appId: 1:1084019484887:web:215f81e1859b86b6a56892
measurementId: G-8MKSCMVYF1
```

### Firebase Console Setup (IMPORTANT - Do This First!)
1. Go to https://console.firebase.google.com → project **trade-ff4a4**
2. **Authentication** → Sign-in method → Enable **Email/Password**
3. **Firestore Database** → Create database → Start in **test mode**
4. **Storage** → Get started → Start in **test mode**

### To Get Service Account Key (For Push Notifications & Advanced Features):
1. Firebase Console → Project Settings (gear icon) → Service Accounts tab
2. Click **"Generate New Private Key"**
3. Download the JSON file
4. Rename it to `firebase-service-account.json` and replace the placeholder file

---

## Quick Deploy on VPS (213.163.205.104)

### Step 1: Upload and Extract
Upload `xtechapp-backend.zip` to your VPS:
```bash
mkdir -p /opt/xtechapp
cd /opt/xtechapp
unzip xtechapp-backend.zip
```

### Step 2: Install Dependencies
```bash
npm install --production
```

### Step 3: Start Server
```bash
npm start
```

### Step 4: Run with PM2 (keeps server running after disconnect)
```bash
npm install -g pm2
pm2 start server.js --name xtechapp
pm2 save
pm2 startup
```

### Step 5: Open Firewall
```bash
sudo ufw allow 5000
```

---

## API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | /api/auth/register | Register with email, password, name, phone |
| POST | /api/auth/login | Login with Firebase ID token |
| POST | /api/auth/check-ip | Check IP account limit |
| GET | /api/users/profile/:uid | Get user profile |
| PUT | /api/users/profile | Update profile (name, about, phone) |
| POST | /api/users/profile-pic | Upload profile picture |
| POST | /api/users/bg-photo | Upload background photo |
| POST | /api/users/fcm-token | Register push notification token |
| GET | /api/users/search?q= | Search users by name/email/phone |
| POST | /api/contacts/sync | Sync phone contacts - find who's on xtechapp |
| POST | /api/chats | Create or get chat with a user |
| GET | /api/chats | Get all user's chats |
| GET | /api/chats/:chatId/messages | Get chat messages |
| POST | /api/messages | Send text message |
| POST | /api/messages/media | Upload media file |
| GET | /api/contacts | Get all app contacts |
| POST | /api/groups | Create a group |
| POST | /api/groups/join | Join group by ID |
| GET | /api/groups/:groupId/invite | Get group invite link |
| POST | /api/status | Post status update |
| GET | /api/status | Get status updates |
| GET | /api/health | Health check |

## Socket.io Events

- `join-chat` / `leave-chat` - Join/leave chat rooms
- `send-message` / `new-message` - Real-time messaging
- `typing` / `stop-typing` - Typing indicators
- `message-read` - Read receipts
- `call-user` / `answer-call` - WebRTC voice/video call signaling
- `ice-candidate` - ICE candidate exchange
- `call-ended` - End call
- `screen-share-started` / `screen-share-stopped` - Screen sharing
- `user-online` / `user-offline` - Presence status

## Notes
- Firebase project: **trade-ff4a4** (already configured)
- Backend uses Firebase Firestore as database
- Make sure Firebase Authentication (Email/Password) is enabled
- Make sure Firestore Database is created (test mode)
- IP-based account limiting is enforced (1 account per IP by default)
- File uploads are stored in the `uploads/` directory
- Without service account key: basic features work (auth, chat, messages)
- With service account key: push notifications work
